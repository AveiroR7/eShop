package com.info.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.info.GlobalData;
import com.info.dao.UserRepository;
import com.info.model.Contact;
import com.info.model.User;
import com.info.service.CategoryService;
import com.info.service.ContactService;
import com.info.service.ProductService;
import com.info.service.UserService;

@Controller
@RequestMapping("/")
public class HomeController {
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private CategoryService categoryService;
	
	@Autowired
	private ProductService productService;
	
	@Autowired
	private ContactService contactService;
	
	@GetMapping({"index", "/"})
	public String index(Model model) {
		model.addAttribute("categoryList", categoryService.listCategory());
		model.addAttribute("productList", productService.listProduct());
		return "index";
	}
	
	@GetMapping("login")
	public String login() {
	
		return "login";
	}
	
	@GetMapping("signup")
	public String signup() {
		return "signup";
	}
	
	@GetMapping("/user_registration")
	public String user_registration() {
		return "user_registration";
	}
	
//	@PostMapping("signup")
//	public ModelAndView signUp(User user) {
//		ModelAndView mv = new ModelAndView("/index");
//		userService.save(user);
//		mv.addObject("productList", productService.listProduct());
//		mv.addObject("categoryList", categoryService.listCategory());
//		return mv;
//	}
	
	
	
	@PostMapping("signup")
	
	public String signUp(@RequestParam String email, User user, HttpSession session ) {
		
		User user1 = this.userRepository.findByEmail(email);

		try {
		if (user.getEmail().equals(user1.getEmail())){
			session.setAttribute("message", "User is exist with this email");
			return "admin/add-user";
		} 
		}catch(Exception e) {
			userService.save(user);
			session.setAttribute("message", "Registration is successfull !!! Please login ");
			return "admin/add-user";
	}
		return "";
	}
	
//	
//	@PostMapping("/user_registration")
//	public ModelAndView user_registration(User user) {
//		ModelAndView mv = new ModelAndView("/index");
//		userService.save(user);
//		mv.addObject("productList", productService.listProduct());
//		mv.addObject("categoryList", categoryService.listCategory());
//		return mv;
//	}
	
	
	@PostMapping("user_registration")
	public String user_registration(@RequestParam String email, User user, HttpSession session ) {
		User user1 = this.userRepository.findByEmail(email);

		try {
		if (user.getEmail().equals(user1.getEmail())){
			session.setAttribute("message", "User is exist with this email");
			return "user_registration";
		} 
		}catch(Exception e) {
			userService.save(user);
			session.setAttribute("message", "Registration is successfull !!! Please login ");

			return "login";
	}
		return "";
	}
	

	@GetMapping("/contact")
	public String contact(Model model) {
		Contact contact = new Contact();
		model.addAttribute("contact",contact);
		return "contact";
	}
	
	@PostMapping("/contact")
	public String contactus(@ModelAttribute Contact contact,Model model) {
		System.out.println(contact);
		this.contactService.saveContact(contact);
		
		return "redirect:/contact";
	}
	
	@GetMapping("allProduct")
	public String allProduct(Model model) {
		model.addAttribute("productList", productService.listProduct());
		model.addAttribute("categoryList", categoryService.listCategory());
		return "index";
	}
	
	@GetMapping("getProducts/{categoryId}")
	public ModelAndView getProductFromCategory(@PathVariable("categoryId")String categoryId) {
		ModelAndView mv = new ModelAndView("index");
		long categoryLongId = Long.parseLong(categoryId);
		System.out.println(categoryLongId);
		mv.addObject("productList", productService.findByCategory(categoryLongId));
		mv.addObject("categoryList", categoryService.listCategory());
		return mv;
	}
	
	@GetMapping("error")
	public String error() {
		return "error";
	}
	
	@GetMapping("home")
	public String home() {
		return "home";
	}

	
}
