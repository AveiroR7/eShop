package com.info.controller;

import java.security.Principal;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.info.GlobalData;
import com.info.model.Checkout;
import com.info.model.Product;
import com.info.model.User;
import com.info.service.CheckoutService;
import com.info.service.IEmailSenderService;
import com.info.service.PaymentService;
import com.info.service.ProductService;
import com.info.service.UserService;

@Controller
@RequestMapping("profile")
public class ProfileController {
	
	@Autowired
	private ProductService productService;
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private IEmailSenderService  emailSenderService;
	
	@Autowired
	private PaymentService paymentService;
	
	@Autowired
	private CheckoutService checkoutService;
	
	@GetMapping("cart-product")
	public ModelAndView cartProduct(Principal principal) {
		ModelAndView mv = new ModelAndView("profile/cart-product");
		User user = userService.findByEmail(principal.getName());
		mv.addObject("user", user);
		int total = findSum(user);
		mv.addObject("total", total);
		return mv;
	}
	
	private int findSum(User user) {
		List<Product> list = user.getProductList();
		int sum =0;
		for(int i=0; i<list.size(); i++) {
			Product p = list.get(i);
			sum+= p.getProductPrice();
		}
		return sum;
	}
	
	

	
	
	@GetMapping("addToCart/{productId}")
		public ModelAndView addToCart(@PathVariable("productId")String productId,Principal principal) {
		ModelAndView mv = new ModelAndView("profile/cart-product");
		User user = userService.findByEmail(principal.getName());
		long productLongId = Long.parseLong(productId);
		Product product = productService.getProductById(productLongId).get();
		
		GlobalData.productList = new ArrayList<Product>();
		GlobalData.productList.add(product);
		user.setProductList(GlobalData.productList);
		
		List<User> userList = new ArrayList<>();
		userList.add(user);
		product.setUserList(userList);
		
		userService.update(user);
		//productService.addProduct(product);
		int total = findSum(user);
		mv.addObject("total", total);
		mv.addObject("user", user);
		return mv;
	}

//	    @GetMapping("deletefromCart/{productId}")
//		public ModelAndView deletefromCart(@PathVariable ("productId")String productId,Principal principal)
//	{
//		ModelAndView mv = new ModelAndView("profile/cart-product");
//		User user = userService.findByEmail(principal.getName());
//		long productLongId = Long.parseLong(productId);
//		Product product = productService.getProductById(productLongId).get();
//		GlobalData.productList.remove(productId);
//		user.setProductList(GlobalData.productList);
//		
//		List<User> userList = new ArrayList<>();
//		userList.add(user);
//		product.setUserList(userList);
//		
//		userService.update(user);
//		int total = findSum(user);
//		mv.addObject("total", total);
//		mv.addObject("user", user);
//		
//		return mv;
//		
//		
//	
//		
//	}
//	
	
	
	
	

//	@GetMapping("deletefromCart/{productId}")
//	public ModelAndView deletefromCart(@PathVariable("productId")String productId,Principal principal) {
//		ModelAndView mv = new ModelAndView("profile/cart-product");
//		User user = userService.findByEmail(principal.getName());
//		long productLongId = Long.parseLong(productId);
//		Product product = productService.getProductById(productLongId).get();
//		
//		List<Product> productList = new ArrayList<Product>();
//		productList.remove(productId);
//		user.setProductList(productList);
//		
//		List<User> userList = new ArrayList<>();
//		userList.remove(user);
//		product.setUserList(userList);
//		
//		userService.update(user);
//		productService.deleteProduct(product);
//		double total = findSum(user);
//		mv.addObject("total", total);
//		mv.addObject("user",user);
//		return mv;
//		
//	}
	
	
//	@GetMapping("deleteItem")
//	public ModelAndView deleteUser(@PathVariable("productId")String productId,Principal principal)throws  InterruptedException {
//		ModelAndView mv = new ModelAndView("profile/cart-product");
//		User user = userService.findByEmail(principal.getName());
//		long productLongId = Long.parseLong(productId);
//		Product product = productService.getProductById(productLongId).get();
//		
//		List<Product> productList = new ArrayList<Product>();
//		productList.remove(product);
//		user.setProductList(productList);
//		
//		List<User> userList = new ArrayList<>();
//		userList.add(user);
//		product.setUserList(userList);
//		
//		userService.update(user);
//		productService.deleteProduct(product.getProductId());
//		int total = findSum(user);
//		mv.addObject("total", total);
//		mv.addObject("user", user);
//		
//		return mv;
//	}

	@GetMapping("checkout")
	public ModelAndView cartProduct1(Checkout checkout, Principal principal)  throws  InterruptedException{
		ModelAndView mv = new ModelAndView("checkout");
//		checkoutService.addCheckout(checkout);
		User user = userService.findByEmail(principal.getName());
		String email = user.getEmail();
		mv.addObject("user", user);
		int total = findSum(user);
		mv.addObject("email" , email);
		mv.addObject("total", total);
		mv.addObject("GSTtotal", total+total*0.18);
		
		return mv;
	}
	
	@PostMapping("placeorder")
	public ModelAndView cartProduct2(Checkout checkout,Principal principal) throws  InterruptedException {
		ModelAndView mv = new ModelAndView("placeorder");
		checkoutService.addCheckout(checkout);
//		paymentService.addPayment(payment);
		User user = userService.findByEmail(principal.getName());
		String email = user.getEmail();
		long id = user.getUserId();
		mv.addObject("user", user);
		int total = findSum(user);
		double gstamt = total+total*0.18;
		mv.addObject("total", total);
		mv.addObject("email" , email);
		mv.addObject("id" , id);
		mv.addObject("GSTtotal", total+total*0.18);
		emailSenderService.sendSimpleEmail(user.getEmail(),
				"Dear " + user.getFirstName() + " " + user.getLastName() + ",\n\n"
						+ "Congratulations! Your order is successfully placed.\n\n"
						+ "payable amount : "+gstamt
						+ "\n\n"+"order id : "+user.getUserId()
						+ "\n"
						+"\n"
						+ "\n"+"THANK YOU !!" +"\n"+ "Warm Regards,\n" + "E-Shop,\n" + "CDAC Mumbai Services",
				"Payment Successful");
		return mv;
	}
	
	
	
	
	
}
