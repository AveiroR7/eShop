package com.info.service;

import com.info.model.Checkout;

public interface CheckoutService {

	
	public void addCheckout(Checkout checkout);
	
}
