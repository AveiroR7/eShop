package com.info.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.info.dao.CheckoutRepository;
import com.info.model.Checkout;

@Service
public class CheckoutServiceImpl implements CheckoutService {

	
	@Autowired
	private CheckoutRepository checkoutRepository;

	@Override
	public void addCheckout(Checkout checkout) {
		// TODO Auto-generated method stub
		checkoutRepository.save(checkout);
		
	}
	
	

}
