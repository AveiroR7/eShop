package com.info.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.info.dao.ContactRepository;
import com.info.model.Contact;

@Service
public class ContactServiceImpl implements ContactService {
	
	@Autowired
	private ContactRepository contactRepository;

	@Override
	public List<Contact> getAllContacts() {
	
		return this.contactRepository.findAll();
	}

	@Override
	public Contact saveContact(Contact contact) {
		return this.contactRepository.save(contact);

	}

}
