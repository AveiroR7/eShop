package com.info.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.info.dao.PaymentRepository;
import com.info.model.Payment;

@Service
@Transactional
public class PaymentServiceImpl implements PaymentService{
	
	@Autowired
	private PaymentRepository paymentRepository;

	@Override
	public void addPayment(Payment payment) {
		// TODO Auto-generated method stub
		paymentRepository.save(payment);
	}

	
	
}
