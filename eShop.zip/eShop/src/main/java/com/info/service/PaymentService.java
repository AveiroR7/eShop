package com.info.service;

import com.info.model.Payment;

public interface PaymentService {

	public void addPayment(Payment payment);
}
