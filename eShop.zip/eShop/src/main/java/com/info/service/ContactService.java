package com.info.service;

import java.util.List;

import com.info.model.Contact;

public interface ContactService {

	
	List<Contact> getAllContacts();
	Contact saveContact(Contact contact);
}
