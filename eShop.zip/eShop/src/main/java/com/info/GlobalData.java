package com.info;

import java.util.*;

import com.info.model.Product;

public class GlobalData {
	
	public static List<Product> productList = new ArrayList<Product> ();
	
	
}
